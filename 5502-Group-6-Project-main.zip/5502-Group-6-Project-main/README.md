# 5502-Group-6-Project

#### Steps to run the `app.py` file:
* Activate your conda environment which has all the libraries mentioned below
* run - `streamlit run app.py` (opens the webpage)

Libraries required to run this project:
* Streamlit
* Pandas
* Numpy
* Matplotlib
* Seaborn
* Scikit Learn

Programming Languange:
* Python

Softwares required:
* Anaconda
* Python
* Jupyter
